#!/usr/bin/python3
"""
Entity mapping model of database
"""
