#!/usr/bin/python3
"""
Encapsulation of public class methods
"""
