#!/usr/bin/python3
"""
    Business approach to package life cycle
"""
